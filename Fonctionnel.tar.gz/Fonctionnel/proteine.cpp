#include "proteine.h"
#include <iostream>
using std::cout;
using std::endl;

Proteine::Proteine(string new_name = "Unknown protein", vector<int> new_data = {}) : name(new_name), data(new_data) {
	//cout << "Nouvelle proteine de nom : " << name << endl;
}
Proteine::~Proteine(){
	
}

void Proteine::setName(string new_name){
	name = new_name;
}

void Proteine::setData(vector<int> new_data){
	data = new_data;
}

string Proteine::getName() const{
	return name;
}

vector<int> Proteine::getData() const{
	return data;
}

int Proteine::getLength() const{
	return data.size();
}

bool Proteine::operator==(const Proteine &protDroite) const{
	return data==protDroite.getData();
}

